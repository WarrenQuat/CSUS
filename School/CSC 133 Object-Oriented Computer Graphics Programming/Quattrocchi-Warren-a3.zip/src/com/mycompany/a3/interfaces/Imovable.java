/*
 * Warren Quattrocchi
 * CSC 133
 * Imovable interface
 */
package com.mycompany.a3.interfaces;

public interface Imovable
{
	public void move(int fps);
}
