/*
 * Warren Quattrocchi
 * CSC 133
 * ICollection interface
 */

package com.mycompany.a3.interfaces;

public interface ICollection 
{
	public void add(Object o);
	public IIterator getIterator();
	
}
