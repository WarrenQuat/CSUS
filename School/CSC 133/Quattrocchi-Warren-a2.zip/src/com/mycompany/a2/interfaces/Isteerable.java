/*
 * Warren Quattrocchi
 * CSC 133
 * Isteerable interface
 */

package com.mycompany.a2.interfaces;

public interface Isteerable 
{	
	public void moveLeft();
	
	public void moveRight();
	
	public void incSpeed();
	
	public void decSpeed();	
}
