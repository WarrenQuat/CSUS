/*
 * Warren Quattrocchi
 * CSC 133
 * Imovable interface
 */
package com.mycompany.a2.interfaces;

public interface Imovable
{
	public void move();
}
