package com.mycompany.quiz5;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.plaf.Border;

public class PointerHandling extends Form
{

	public PointerHandling()
	{
		this.setLayout(new BorderLayout());
		Container click = new Container();
		Container drag = new Container();
		Container release = new Container();
		click.add(new Label("	click        "));
		drag.add(new Label("	drag	"));
		release.add(new Label("   release	"));
		//PointerContainer pc = new PointerContainer();
		this.add(BorderLayout.WEST,click);
		this.add(BorderLayout.CENTER,drag);
		this.add(BorderLayout.EAST,release);
		click.getAllStyles().setBorder(Border.createLineBorder(4,ColorUtil.YELLOW));
		drag.getAllStyles().setBorder(Border.createLineBorder(4,ColorUtil.GREEN));
		release.getAllStyles().setBorder(Border.createLineBorder(4,ColorUtil.BLUE));
		click.addPointerPressedListener(new PointerClickedListener());
		drag.addPointerDraggedListener(new PointerDraggedListener());
		release.addPointerReleasedListener(new PointerReleasedListener());
		this.show();
	}

public class PointerClickedListener implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
		System.out.println("Pointer PRESSED x and y: " + evt.getX() + " " + evt.getY());
	}
}
public class PointerReleasedListener implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
		System.out.println("Pointer RELEASED x and y: " + evt.getX() + " " + evt.getY());
	}
}
public class PointerDraggedListener implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
		System.out.println("Pointer DRAGGED x and y: " + evt.getX() + " " + evt.getY());
	}
}
}
