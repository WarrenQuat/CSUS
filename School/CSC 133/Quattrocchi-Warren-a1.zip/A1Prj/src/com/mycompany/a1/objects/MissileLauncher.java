/*
 * Warren Quattrocchi
 * CSC 133
 * MissileLauncher Abstract Class
 */

package com.mycompany.a1.objects;

public abstract class MissileLauncher extends MovableObject
{

	
}
